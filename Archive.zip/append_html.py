import re

with open('report/main.tex', 'r') as f:
    tex = f.read()

# Load html
with open('codes/web-vm/templates/login.html', 'r') as f:
    login_html = f.read()

with open('codes/web-vm/templates/dashboard.html', 'r') as f:
    dashboard_html = f.read()

appendix = r'''
\newpage
\appendix
\section{Web VM HTML Templates}
\subsection{\texttt{login.html}}
\begin{lstlisting}[language=html, caption=templates/login.html]
''' + login_html + r'''\end{lstlisting}

\subsection{\texttt{dashboard.html}}
\begin{lstlisting}[language=html, caption=templates/dashboard.html]
''' + dashboard_html + r'''\end{lstlisting}
'''

tex = tex.replace(r'\end{document}', appendix + '\n\\end{document}')

with open('report/main.tex', 'w') as f:
    f.write(tex)
