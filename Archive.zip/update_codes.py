import re
import os

def replace_block(tex_content, caption_marker, file_path):
    with open(file_path, 'r') as f:
        code = f.read()
    
    # Find the block starting with the caption_marker and ending with \end{lstlisting}
    pattern = r'(\\begin\{lstlisting\}\[.*?caption=.*?' + re.escape(caption_marker) + r'.*?\]\n)(.*?)(\\end\{lstlisting\})'
    
    def replacer(match):
        return match.group(1) + code + match.group(3)
        
    new_content, count = re.subn(pattern, replacer, tex_content, flags=re.DOTALL)
    print(f"Replaced {count} instances for {caption_marker}")
    return new_content

with open('report/main.tex', 'r') as f:
    tex = f.read()

tex = replace_block(tex, 'auth-vm/main.go', 'codes/auth-vm/main.go')
tex = replace_block(tex, 'file-vm/main.go', 'codes/file-vm/main.go')
tex = replace_block(tex, 'pubsub/broker.go', 'codes/pubsub/broker.go')
tex = replace_block(tex, 'pubsub/subscriber.go', 'codes/pubsub/subscriber.go')

with open('report/main.tex', 'w') as f:
    f.write(tex)
