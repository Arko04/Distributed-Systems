import re

with open('report/main.tex', 'r') as f:
    tex = f.read()

# Emojis left: 👋, 🔄, 📢, 💾, and em-dash –
emojis = ['👋', '🔄', '📢', '💾', '–']

for e in emojis:
    tex = tex.replace(e, '')

with open('report/main.tex', 'w') as f:
    f.write(tex)
