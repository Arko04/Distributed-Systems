import re

with open('report/main.tex', 'r') as f:
    tex = f.read()

with open('codes/web-vm/main.go', 'r') as f:
    webvm_code = f.read()

# Emojis to strip
emojis = ['📥', '🚀', '❌', '🛑', '⚠️', '✅', '📡', '🔌', '📨', '👋', '🔄', '📢', '💾', '–']
for e in emojis:
    webvm_code = webvm_code.replace(e, '')
    
webvm_code_clean = ""
for char in webvm_code:
    if ord(char) < 128:
        webvm_code_clean += char
webvm_code = webvm_code_clean

start_pattern = r'\\begin\{lstlisting\}\[language=go, caption=web-vm/main\.go - Full version with explanatory comments\]'
match = re.search(start_pattern, tex)
if match:
    start_idx = match.start()
    
    end_pattern = r'\\subsubsection\{VM2: Authentication Service'
    match_end = re.search(end_pattern, tex[start_idx:])
    
    if match_end:
        end_idx = start_idx + match_end.start()
        
        new_chunk = r'''\begin{lstlisting}[language=go, caption=web-vm/main.go - Full version]
''' + webvm_code + r'''\end{lstlisting}

'''
        tex = tex[:start_idx] + new_chunk + tex[end_idx:]
        print("Replaced web-vm chunks with single full version.")
    else:
        print("Could not find the end of the web-vm section.")
else:
    print("Could not find the start of the web-vm section.")

with open('report/main.tex', 'w') as f:
    f.write(tex)
