import re

with open('report/main.tex', 'r') as f:
    tex = f.read()

# Replace any character outside the basic ASCII range (but keep newlines, tabs)
tex_clean = ""
for char in tex:
    if ord(char) < 128:
        tex_clean += char
    else:
        # keep standard quotes or dashes if necessary, but actually the only issue is emojis and box drawing
        pass

with open('report/main.tex', 'w') as f:
    f.write(tex_clean)
