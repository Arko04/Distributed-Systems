import os

with open('codes/web-vm/main.go', 'r') as f:
    code = f.read()

with open('report/main.tex', 'r') as f:
    tex = f.read()

appendix = r'''
\newpage
\appendix
\section{Complete Source Code for Web VM (\texttt{web-vm/main.go})}
As the Web VM is the core orchestrator of the system, its full source code, including all error handling, graceful shutdown, logging middleware, and environment variable parsing, is provided below.

\begin{lstlisting}[language=go, caption=Complete web-vm/main.go]
''' + code + r'''\end{lstlisting}
'''

tex = tex.replace(r'\end{document}', appendix + '\n\\end{document}')

with open('report/main.tex', 'w') as f:
    f.write(tex)
