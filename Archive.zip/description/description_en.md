# Assignment 2: Distributed Systems – Remote Procedure Call (RPC)

## University of Tehran
### Student: Electrical and Computer Engineering
### Course: Fundamentals of Distributed Computing
### Second Assignment (2)
### Instructor: Mohammadreza Shourniya
### Teaching Assistant: Pooya Jamshidi
### Assignment TAs: Kazem Ayarzadeh, Mohammad Afzal Zadeh
### Spring 2026

---

## Table of Contents

1. Assignment Topic  
2. Assignment Objectives  
3. General Rules  
4. Recommended Project Structure  
5. Overall System View  
6. Part One: Introduction to RPC and Its Various Technologies  
7. Part Two: Implementing a Distributed System with Multiple Virtual Machines  
8. Part Three: Adding Pub/Sub and Memory Usage Alerts  
9. Documentation and Report  
10. Deliverables  
11. Evaluation Criteria  
12. Penalties  
13. Learning Outcomes

---

## 3. General Rules

## 1. Assignment Topic

The topic of this assignment is to become familiar with the concepts of Remote Procedure Call (RPC), designing distributed services, communication between multiple virtual machines, separation of duties among services, and using the Publish/Subscribe pattern to monitor and announce events.

In this assignment, you must design and implement a small distributed system consisting of several independent virtual machines. Each virtual machine has a specific role in the system, and communication between components must occur over the network.

## 2. Assignment Objectives

The main objectives of this assignment are:

- Theoretical and practical familiarity with the concept of RPC
- Understanding the differences between RPC and REST, and direct network communications
- Designing a multi‑service system on multiple virtual machines
- Implementing user authentication using RPC
- Separating web service, authentication service, and file service
- Implementing a simple Publish/Subscribe framework
- Monitoring memory usage of a service and sending alerts when a specified threshold is exceeded

## 3. General Rules

- The recommended programming language for implementing services is Go.
- Using other languages is allowed only with the instructor's approval.
- The project must run on a Linux environment.
- At least three independent virtual machines must be used.
- Services must communicate with each other via the network addresses of the virtual machines.
- Running all components on a single machine or only via localhost is not acceptable.
- Each service must have its own README file for execution and testing.
- All execution instructions must be precise, reproducible, and unambiguous.

---

## 4. Recommended Project Structure

The recommended project submission structure is as follows:

```
HW2/
  report.pdf
  rpc-study/
    rpc-summary.pdf
  web-vm/
    main.go
    templates/
    static/
    README.md
  auth-vm/
    main.go
    users.json
    README.md
  file-vm/
    main.go
    files/
      images/
    README.md
  pubsub/
    publisher.go
    subscriber.go
    README.md
  screenshots/
```

---

## 5. Overall System View

```
User Browser
      |
      v
+------------------+
| VM1: Web Server  |
+------------------+
      | RPC                | HTTP/RPC
      v                   v
+------------------+   +------------------+
| VM2: Auth Server |   | VM3: File Server |
+------------------+   +------------------+
```

Additionally:
- VM1 publishes memory usage events.
- A subscriber receives alerts when memory usage exceeds a threshold.

You must have at least three virtual machines:

- **VM1:** Web service and user interface
- **VM2:** User authentication service
- **VM3:** File and images service

---

## 6. Part One: Introduction to RPC and Its Various Technologies

### 6–0.1 Description of this Part

In this part, you must prepare a comprehensive report about RPC. This section may be purely theoretical, but it must be precise, technical, and include a comparison of different technologies.

### 6–1 Mandatory Contents of the Report

The report for this part must at least include the following:

1. Definition of RPC
2. The core idea of calling a remote function
3. Difference between local invocation and remote invocation
4. Role of Client Stub and Server Stub
5. Concept of Serialization and Deserialization
6. Concept of IDL (Interface Definition Language)
7. Common RPC errors
8. Comparison of RPC with REST
9. Comparison of several popular RPC technologies

### 6–2 Technologies to be Reviewed

At least three of the following technologies must be reviewed and compared:

- gRPC
- JSON-RPC
- XML-RPC
- Apache Thrift
- Java RMI
- SOAP

### 6–3 Comparison Criteria

The comparison of technologies must be based on the following criteria:

- Data type and message format
- Method of interface definition
- Support for multiple programming languages
- Performance and communication overhead
- Ease of implementation
- Suitability for distributed systems
- Streaming support
- Common use cases

### 6–4 Mandatory Comparison Table

The report must contain at least one comparison table like the example below:

| Use Case        | Streaming | IDL       | Data Format      | Technology   |
|----------------|-----------|-----------|------------------|--------------|
| Microservices  | Yes       | Yes       | Protocol Buffers | gRPC         |
| Simple APIs    | No        | No/Optional | JSON             | JSON-RPC    |
| Legacy Systems | No        | No        | XML              | XML-RPC      |

### 6–5 Mandatory Analytical Questions

The report must answer the following questions:

1. Why does RPC make a remote service call appear like a local function call?
2. Why can this similarity be dangerous or misleading?
3. What errors can occur in remote invocations that do not exist in local invocations?
4. In what situations is gRPC a better choice than REST?
5. In what situations is REST a simpler or more appropriate choice?

---

## 7. Part Two: Implementing a Distributed System with Multiple Virtual Machines

### 7–1 General Description

In this part, you must implement a small system consisting of several independent services. Each service must run on a separate virtual machine and communicate over the network with other services.

### 7–2 Required Virtual Machines

At least three virtual machines must be created:

- **VM1:** Web service machine
- **VM2:** Authentication service machine
- **VM3:** File and images service machine

If needed, you can use a fourth machine for a Pub/Sub broker or monitoring subscriber, but it is not mandatory.

### 7–3 VM1: Web Service

#### 7–3.1 Function of the Web Service

This machine must run a simple web page. The user enters this page via a browser and sees a login form.

#### 7–3.2 Mandatory Requirements

1. The web service must have at least one login page.
2. The login page must include username and password fields.
3. After submitting the form, the web service must not perform authentication itself.
4. The web service must send an RPC to the authentication service on VM2 to verify credentials.
5. If login is successful, a welcome page must be displayed.
6. If login fails, an appropriate error message must be shown.
7. After successful login, the web page must be able to retrieve and display at least one file or image from VM3.

#### 7–3.3 Expected Behavior

Example system behavior:

1. User enters the web service address.
2. Login form is displayed.
3. User enters username and password.
4. VM1 sends an authentication request via RPC to VM2.
5. VM2 returns the result.
6. If successful, VM1 displays the main page.
7. The main page retrieves an image or file from VM3.

### 7–4 VM2: Authentication Service

#### 7–4.1 Function of the Authentication Service

This machine must contain user data and authentication functions. The web service must not directly access the user file or internal data of this service.

#### 7–4.2 Mandatory Requirements

1. The authentication service must have an RPC procedure to verify login.
2. This procedure must accept at least two inputs: `username` and `password`.
3. The output must indicate whether the login was successful or not.
4. User data must be stored on VM2.
5. VM1 must not have direct access to the user file.
6. At least three test users must be defined.

#### 7–4.3 Example User Data

```json
[
  {
    "username": "alice",
    "password": "alice123"
  },
  {
    "username": "bob",
    "password": "bob123"
  },
  {
    "username": "admin",
    "password": "admin123"
  }
]
```

**Security note:** For simplicity, storing plain text passwords is acceptable. However, students who hash passwords will receive extra design points.

#### 7–4.4 Example Service Definition

If using gRPC, the service definition could look like this:

```protobuf
service AuthService {
  rpc Login(LoginRequest) returns (LoginResponse);
}
```

### 7–5 VM3: File and Images Service

#### 7–5.1 Function of the File Service

This machine acts as a simple file and image storage. The web service on VM1 must be able to retrieve a file or image from this machine after successful login.

#### 7–5.2 Mandatory Requirements

1. Several files or images must be placed on VM3.
2. VM3 must run a simple service to serve these files.
3. VM1 must be able to retrieve a file or image from VM3 over the network.
4. The path or address of the files must not be local to VM1.
5. The report must specify how the files are retrieved from VM3.

#### 7–5.3 Acceptable Methods

For the file service, you may use one of the following methods:

- HTTP File Server
- RPC-based File Service
- A simple custom service in Go

The simplest acceptable method is using an HTTP File Server, but if you also implement file retrieval via RPC, you will receive extra design points.

---

## 8. Part Three: Adding Pub/Sub and Memory Usage Alerts

### 8–1 Problem Description

In this part, you must add a simple Publish/Subscribe framework to the system. The goal is to monitor the memory usage of the web service on VM1, and if memory usage exceeds a specified threshold, an event is published and a subscriber receives it and displays an alert.

### 8–2 Mandatory Requirements

1. Memory usage of the web service must be monitored periodically.
2. A memory usage threshold must be defined.
3. Recommended default threshold: **300 MB**
4. If memory usage exceeds the threshold, an event must be published.
5. At least one subscriber must receive this event.
6. After receiving the event, a clear alert must be displayed.
7. A method must be provided to intentionally increase the web service's memory usage so that the alert can be tested.

### 8–3 Expected Event Structure

The published event may contain the following information:

```json
{
  "event_type": "HIGH_MEMORY_USAGE",
  "service": "web-server",
  "memory_mb": 345,
  "threshold_mb": 300,
  "timestamp": "2026-..."
}
```

### 8–4 Acceptable Methods for Pub/Sub

The following methods are acceptable:

- Simple Pub/Sub implementation using TCP or HTTP
- Using Redis Pub/Sub
- Using RabbitMQ
- Using NATS
- Simple implementation with WebSockets

For simplicity, implementing a small broker in Go is acceptable. In that case, the web service acts as the publisher and another program acts as the subscriber.

### 8–5 Memory Usage Monitoring

To monitor memory usage, you can use standard Go libraries. For example, using `runtime.ReadMemStats` is acceptable.

Recommended metrics:

- `Alloc`
- `HeapAlloc`
- `Sys`

### 8–6 Intentional Memory Consumption Increase

To test the system, you must provide a specific method to increase the memory usage of the web service. For example:

- An endpoint named `/consume-memory`
- Each call to this endpoint allocates a certain amount of memory
- The allocated memory must be kept in a global structure so that it is not freed immediately

Example request:

```
curl http://WEB_VM_IP:8080/consume-memory?mb=100
```

### 8–7 Expected Behavior

1. The web service starts.
2. The subscriber starts and waits for events.
3. Memory usage of the web service is below the threshold.
4. After calling `/consume-memory`, memory usage increases.
5. Once the threshold is exceeded, the web service publishes an event.
6. The subscriber receives the event.
7. An alert message is displayed.

### 8–8 Protocols and Technologies for RPC Communication between VM1 and VM2

You may use one of the following methods for RPC between VM1 and VM2:

- gRPC
- JSON-RPC
- XML-RPC
- Simple RPC-like implementation with HTTP and JSON

However, if you use plain HTTP REST, you must explain in your report why you consider it RPC-like and what the differences with true RPC are. Using gRPC or JSON-RPC gives higher design points.

### 8–9 Mandatory Test Scenario

In your report, you must execute and document the following test scenario:

1. Show the IP addresses of each virtual machine.
2. Run the authentication service on VM2.
3. Run the file service on VM3.
4. Run the web service on VM1.
5. Open the web page from the host system or another client.
6. Attempt to log in with incorrect credentials.
7. Observe the login error message.
8. Attempt to log in with correct credentials.
9. Observe the success page.
10. Retrieve or display a file/image from VM3.
11. Run the subscriber.
12. Intentionally increase the web service's memory usage.
13. Observe the high memory alert.

---

## 9. Documentation and Report

The final report must include the following:

- Overall system architecture
- Role of each virtual machine
- IP address of each virtual machine
- Chosen RPC technology
- Reason for choosing that RPC technology
- Description of implemented procedures
- Explanation of how files are retrieved from VM3
- Explanation of the Pub/Sub framework
- Explanation of the memory monitoring method
- Screenshots or terminal output from successful execution of each part
- Challenges and limitations encountered during implementation

---

## 10. Deliverables

The following items must be submitted:

- Complete code of the web service
- Complete code of the authentication service
- Complete code of the file service
- Code related to Pub/Sub
- User data file
- Sample files or images used
- Final report in PDF format
- README file for each service
- Screenshots of system execution

---

## 11. Evaluation Criteria

### 11–1 Part One: RPC Report – 25 points

- Accurate explanation of RPC concept: 5
- Explanation of RPC components (serialization, stub, IDL): 5
- Comparison of at least three RPC technologies: 6
- Comparison of RPC and REST: 4
- Answers to analytical questions: 5

### 11–2 Part Two: Multi‑VM System – 50 points

- Correct setup of at least three virtual machines: 8
- Implementation of web page and login form: 7
- Correct implementation of authentication service: 8
- Real use of RPC between VM1 and VM2: 10
- Separation of user data from web service: 4
- Implementation of file service on VM3: 6
- Successful retrieval of file/image from VM3: 4
- Error handling and code quality: 3

### 11–3 Part Three: Pub/Sub and Memory Monitoring – 25 points

- Periodic monitoring of web service memory usage: 5
- Definition and checking of memory threshold: 4
- Implementation of event publishing: 5
- Implementation of subscriber and event reception: 5
- Providing a method to intentionally increase memory usage: 3
- Documentation and display of alerts: 3

---

## 12. Penalties

The following will result in score deductions:

- Running all services on a single machine without using actual multiple VMs
- Using localhost instead of network addresses of virtual machines
- Performing authentication on the web service instead of VM2
- Absence of user file on VM2
- No real communication between VM1 and VM3
- No real Pub/Sub – just printing a manual alert
- No reproducible test scenario
- Missing README files
- Missing screenshots or terminal output proving execution

---

## 13. Learning Outcomes

At the end of this assignment, you should be able to demonstrate that:

- You understand the concept of RPC and its various technologies
- You can run multiple independent services on several virtual machines
- You can connect a web service to a remote authentication service
- You can design a separate file service
- You can publish and receive system events using the Publish/Subscribe pattern
- You can document and analyze the behavior of a distributed system