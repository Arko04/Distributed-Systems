import os
import re

files_to_append = [
    "codes/get-docker.sh",
    "codes/docker-compose.yml",
    "codes/README.md",
    "codes/file-vm/Dockerfile",
    "codes/file-vm/Makefile",
    "codes/file-vm/install.sh",
    "codes/file-vm/run.sh",
    "codes/file-vm/test_client.go",
    "codes/file-vm/README.md",
    "codes/pubsub/Dockerfile.broker",
    "codes/pubsub/Dockerfile.subscriber",
    "codes/pubsub/run-broker.sh",
    "codes/pubsub/run-subscriber.sh",
    "codes/pubsub/README.md",
    "codes/auth-vm/brew_install.sh",
    "codes/auth-vm/Dockerfile",
    "codes/auth-vm/install.sh",
    "codes/auth-vm/run.sh",
    "codes/auth-vm/test_client.go",
    "codes/auth-vm/README.md",
    "codes/web-vm/Dockerfile",
    "codes/web-vm/Makefile",
    "codes/web-vm/install.sh",
    "codes/web-vm/run.sh",
    "codes/web-vm/README.md",
]

appendix_str = r'''
\newpage
\section{Complete Auxiliary Source Code Files}
This appendix contains all remaining configuration files, Dockerfiles, shell scripts, test clients, and READMEs to ensure the code listings are fully complete.
'''

emojis = ['📥', '🚀', '❌', '🛑', '⚠️', '✅', '📡', '🔌', '📨', '👋', '🔄', '📢', '💾', '–']

for filepath in files_to_append:
    if os.path.exists(filepath):
        with open(filepath, 'r') as f:
            content = f.read()
        for e in emojis:
            content = content.replace(e, '')
        
        # Escape some latex characters if it's not in a listing... 
        # But we will put it in a listing!
        filename = filepath.replace("codes/", "")
        
        lang = "bash"
        if filename.endswith(".go"): lang = "go"
        elif filename.endswith(".yml") or filename.endswith(".yaml"): lang = "yaml"
        elif "Dockerfile" in filename: lang = "docker"
        elif filename.endswith(".md"): lang = "markdown"
        
        appendix_str += f"\n\\subsection{{\\texttt{{{filename}}}}}\n"
        appendix_str += f"\\begin{{lstlisting}}[language={lang}, caption={filename}]\n"
        appendix_str += content
        appendix_str += "\n\\end{lstlisting}\n"

with open('report/main.tex', 'r') as f:
    tex = f.read()

tex = tex.replace(r'\end{document}', appendix_str + '\n\\end{document}')

with open('report/main.tex', 'w') as f:
    f.write(tex)

